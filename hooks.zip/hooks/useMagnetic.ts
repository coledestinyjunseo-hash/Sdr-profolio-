'use client';

import { useEffect, useRef } from 'react';
import { gsap } from '@/lib/gsap';
import { isTouchDevice } from '@/lib/utils';

interface Options {
  strength?: number;
  ease?: string;
  duration?: number;
}

export function useMagnetic<T extends HTMLElement = HTMLElement>(opts: Options = {}) {
  const { strength = 0.35, ease = 'power3.out', duration = 0.5 } = opts;
  const ref = useRef<T | null>(null);

  useEffect(() => {
    if (isTouchDevice()) return;
    const el = ref.current;
    if (!el) return;

    const xTo = gsap.quickTo(el, 'x', { duration, ease });
    const yTo = gsap.quickTo(el, 'y', { duration, ease });

    const onMove = (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      xTo((e.clientX - cx) * strength);
      yTo((e.clientY - cy) * strength);
    };
    const onLeave = () => {
      xTo(0);
      yTo(0);
    };

    el.addEventListener('mousemove', onMove);
    el.addEventListener('mouseleave', onLeave);

    return () => {
      el.removeEventListener('mousemove', onMove);
      el.removeEventListener('mouseleave', onLeave);
    };
  }, [strength, ease, duration]);

  return ref;
}
