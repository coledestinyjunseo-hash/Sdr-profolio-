'use client';

import { useEffect, useState } from 'react';
import { getLenis } from './useLenis';

export function useScrollVelocity() {
  const [velocity, setVelocity] = useState(0);

  useEffect(() => {
    const lenis = getLenis();
    if (!lenis) return;
    const handler = (e: { velocity: number }) => setVelocity(e.velocity);
    lenis.on('scroll', handler);
    return () => lenis.off('scroll', handler);
  }, []);

  return velocity;
}
