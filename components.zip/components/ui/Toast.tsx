'use client';

import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { gsap } from '@/lib/gsap';

interface ToastCtx {
  showToast: (msg: string) => void;
}

const ToastContext = createContext<ToastCtx | null>(null);

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [message, setMessage] = useState<string | null>(null);
  const ref = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const showToast = useCallback((msg: string) => {
    setMessage(msg);
  }, []);

  useEffect(() => {
    if (!message || !ref.current) return;
    gsap.fromTo(
      ref.current,
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.45, ease: 'back.out(1.5)' }
    );
    timeoutRef.current = setTimeout(() => {
      if (ref.current) {
        gsap.to(ref.current, {
          y: 30,
          opacity: 0,
          duration: 0.35,
          onComplete: () => setMessage(null),
        });
      }
    }, 3200);
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [message]);

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      {message && (
        <div
          ref={ref}
          className="fixed bottom-10 left-1/2 -translate-x-1/2 px-8 py-4 rounded-2xl z-[100000] font-mono text-[13px] text-gold pointer-events-none opacity-0"
          style={{
            background: 'rgba(200,165,92,0.15)',
            border: '1px solid rgba(200,165,92,0.3)',
            backdropFilter: 'blur(20px)',
          }}
        >
          {message}
        </div>
      )}
    </ToastContext.Provider>
  );
}
