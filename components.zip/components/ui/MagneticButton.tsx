'use client';

import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { useMagnetic } from '@/hooks/useMagnetic';
import { cn } from '@/lib/utils';

interface MagneticButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary';
  strength?: number;
  children: ReactNode;
}

const MagneticButton = forwardRef<HTMLButtonElement, MagneticButtonProps>(
  ({ children, variant = 'primary', strength = 0.35, className, ...rest }, _ref) => {
    const magRef = useMagnetic<HTMLButtonElement>({ strength });

    return (
      <button
        ref={magRef}
        className={cn(
          variant === 'primary' ? 'btn-primary' : 'btn-secondary',
          'transform-gpu will-change-transform',
          className
        )}
        {...rest}
      >
        <span className="inline-flex items-center gap-2 relative z-[1]">{children}</span>
      </button>
    );
  }
);
MagneticButton.displayName = 'MagneticButton';

export default MagneticButton;
