'use client';

import {
  forwardRef,
  useRef,
  useImperativeHandle,
  type HTMLAttributes,
  type ReactNode,
} from 'react';
import { gsap } from '@/lib/gsap';
import { cn, isTouchDevice } from '@/lib/utils';

interface GlassCardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  tilt?: boolean;
  hover?: boolean;
  intensity?: number;
}

const GlassCard = forwardRef<HTMLDivElement, GlassCardProps>(
  ({ children, tilt = false, hover = true, intensity = 8, className, ...rest }, externalRef) => {
    const ref = useRef<HTMLDivElement>(null);

    // Expose internal ref to parent so GSAP animation targets work.
    useImperativeHandle(externalRef, () => ref.current as HTMLDivElement, []);

    const onMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
      if (!tilt || !ref.current || isTouchDevice()) return;
      const el = ref.current;
      const rect = el.getBoundingClientRect();
      const rotateX = ((e.clientY - rect.top - rect.height / 2) / rect.height) * -intensity;
      const rotateY = ((e.clientX - rect.left - rect.width / 2) / rect.width) * intensity;
      gsap.to(el, {
        rotateX,
        rotateY,
        scale: 1.02,
        duration: 0.4,
        ease: 'power2.out',
        transformPerspective: 1000,
      });
    };

    const onMouseLeave = () => {
      if (!tilt || !ref.current) return;
      gsap.to(ref.current, {
        rotateX: 0,
        rotateY: 0,
        scale: 1,
        duration: 0.6,
        ease: 'elastic.out(1,0.5)',
      });
    };

    return (
      <div
        ref={ref}
        onMouseMove={onMouseMove}
        onMouseLeave={onMouseLeave}
        className={cn('glass transform-gpu', hover && 'glass-hover', className)}
        {...rest}
      >
        {children}
      </div>
    );
  }
);
GlassCard.displayName = 'GlassCard';

export default GlassCard;
