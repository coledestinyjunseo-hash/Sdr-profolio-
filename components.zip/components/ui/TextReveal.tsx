'use client';

import { useRef, useEffect, type ReactNode, createElement } from 'react';
import { gsap, ScrollTrigger } from '@/lib/gsap';
import { cn } from '@/lib/utils';

type TagName = 'div' | 'span' | 'h1' | 'h2' | 'h3' | 'p';

interface TextRevealProps {
  children: ReactNode;
  delay?: number;
  duration?: number;
  className?: string;
  trigger?: 'auto' | 'scroll';
  as?: TagName;
}

export default function TextReveal({
  children,
  delay = 0,
  duration = 1,
  className,
  trigger = 'auto',
  as = 'div',
}: TextRevealProps) {
  const wrapperRef = useRef<HTMLElement | null>(null);
  const innerRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (!innerRef.current) return;
    let st: ScrollTrigger | null = null;

    if (trigger === 'auto') {
      gsap.to(innerRef.current, {
        y: 0,
        duration,
        delay,
        ease: 'power4.out',
      });
    } else {
      const tween = gsap.to(innerRef.current, {
        y: 0,
        duration,
        delay,
        ease: 'power4.out',
        scrollTrigger: {
          trigger: wrapperRef.current,
          start: 'top 85%',
          toggleActions: 'play none none reverse',
        },
      });
      st = tween.scrollTrigger ?? null;
    }

    return () => {
      st?.kill();
    };
  }, [delay, duration, trigger]);

  return createElement(
    as,
    {
      ref: wrapperRef,
      className: cn('text-reveal-mask', className),
    },
    <span ref={innerRef} className="text-reveal-inner">
      {children}
    </span>
  );
}
