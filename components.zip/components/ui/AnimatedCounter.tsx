'use client';

import { useEffect, useRef, useState } from 'react';
import { gsap, ScrollTrigger } from '@/lib/gsap';

interface AnimatedCounterProps {
  target: number;
  suffix?: string;
  duration?: number;
  className?: string;
}

export default function AnimatedCounter({
  target,
  suffix = '',
  duration = 2,
  className = '',
}: AnimatedCounterProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!ref.current) return;
    const obj = { v: 0 };
    let trigger: ScrollTrigger | null = null;

    const ctx = gsap.context(() => {
      trigger = ScrollTrigger.create({
        trigger: ref.current!,
        start: 'top 90%',
        once: true,
        onEnter: () => {
          gsap.to(obj, {
            v: target,
            duration,
            ease: 'power2.out',
            onUpdate: () => setValue(obj.v),
          });
        },
      });
    });

    return () => {
      trigger?.kill();
      ctx.revert();
    };
  }, [target, duration]);

  return (
    <span ref={ref} className={className}>
      {Math.floor(value)}
      {suffix}
    </span>
  );
}
