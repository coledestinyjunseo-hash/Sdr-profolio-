'use client';

import { useEffect, useState } from 'react';
import { NAV_LINKS, SITE } from '@/lib/constants';
import { scrollToSection } from '@/hooks/useLenis';
import { cn } from '@/lib/utils';

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-[9000] px-6 md:px-10 py-5 flex justify-between items-center transition-all duration-500',
        scrolled && 'backdrop-blur-2xl bg-bg/70 border-b border-white/[0.06]'
      )}
    >
      <button
        onClick={() => scrollToSection('hero')}
        className="font-mono font-bold text-sm tracking-[0.18em] text-gold hover:text-gold-300 transition-colors"
        aria-label="Back to top"
      >
        {SITE.shortName}
      </button>

      <div className="hidden md:flex items-center gap-8">
        {NAV_LINKS.map((link) => (
          <button
            key={link.to}
            onClick={() => scrollToSection(link.to)}
            className="font-mono text-[11px] tracking-[0.12em] uppercase text-white/40 hover:text-gold transition-colors"
          >
            {link.label}
          </button>
        ))}
      </div>

      <div className="hidden md:flex items-center gap-3 font-mono text-[10px] tracking-[0.2em] text-white/30 uppercase">
        <span className="pulse-dot" /> Available
      </div>
    </nav>
  );
}
