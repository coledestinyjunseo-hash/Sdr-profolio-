'use client';

import { useEffect, useState } from 'react';
import { SECTIONS, type SectionId } from '@/lib/constants';
import { scrollToSection } from '@/hooks/useLenis';
import { cn } from '@/lib/utils';

export default function SectionIndicator() {
  const [active, setActive] = useState<SectionId>('hero');

  useEffect(() => {
    const observers: IntersectionObserver[] = [];
    SECTIONS.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      const obs = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) setActive(id);
        },
        { threshold: 0.4, rootMargin: '-20% 0px -40% 0px' }
      );
      obs.observe(el);
      observers.push(obs);
    });
    return () => observers.forEach((o) => o.disconnect());
  }, []);

  return (
    <div className="hidden lg:flex fixed right-6 top-1/2 -translate-y-1/2 z-[9000] flex-col gap-3.5">
      {SECTIONS.map((id) => {
        const isActive = active === id;
        return (
          <button
            key={id}
            onClick={() => scrollToSection(id)}
            aria-label={`Scroll to ${id}`}
            className={cn(
              'group flex items-center gap-2 transition-all',
              isActive ? 'pr-1' : ''
            )}
          >
            <span
              className={cn(
                'block w-2 h-2 rounded-full border transition-all duration-400',
                isActive
                  ? 'bg-gold border-gold shadow-[0_0_10px_rgba(200,165,92,0.6)] scale-110'
                  : 'border-white/20 bg-transparent'
              )}
            />
            <span
              className={cn(
                'font-mono text-[10px] tracking-[0.2em] uppercase whitespace-nowrap transition-all duration-300',
                isActive
                  ? 'text-gold opacity-100 translate-x-0'
                  : 'opacity-0 -translate-x-2 group-hover:opacity-60 group-hover:translate-x-0 text-white/50'
              )}
            >
              {id}
            </span>
          </button>
        );
      })}
    </div>
  );
}
