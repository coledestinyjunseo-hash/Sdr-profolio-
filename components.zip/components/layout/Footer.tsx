import { SITE } from '@/lib/constants';

export default function Footer() {
  return (
    <footer className="relative z-10 border-t border-white/[0.06] py-10 px-6">
      <div className="max-w-[1200px] mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="text-xs text-white/20 font-mono tracking-wider">
          © {new Date().getFullYear()} {SITE.name}. All rights reserved.
        </div>
        <div className="flex items-center gap-6 text-[10px] font-mono tracking-[0.25em] uppercase text-white/30">
          <span>Crafted in Lagos</span>
          <span className="w-1 h-1 rounded-full bg-white/20" />
          <span className="text-gold/70">v1.0</span>
        </div>
      </div>
    </footer>
  );
}
