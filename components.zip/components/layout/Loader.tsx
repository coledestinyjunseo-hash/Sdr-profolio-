'use client';

import { useEffect, useRef, useState } from 'react';
import { gsap } from '@/lib/gsap';

interface LoaderProps {
  onComplete: () => void;
}

export default function Loader({ onComplete }: LoaderProps) {
  const [pct, setPct] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const numRef = useRef<HTMLDivElement>(null);
  const txtRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Premium intro
    const tl = gsap.timeline();
    tl.from(logoRef.current, {
      opacity: 0,
      y: 20,
      duration: 0.8,
      ease: 'power3.out',
    })
      .to(barRef.current, {
        width: '280px',
        duration: 1.4,
        ease: 'power2.out',
      }, '-=0.4')
      .to(txtRef.current, { opacity: 1, duration: 0.4 }, '-=0.6');

    // Progress simulation
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 12 + 4;
      if (progress > 100) progress = 100;
      setPct(Math.floor(progress));
      if (progress >= 100) {
        clearInterval(interval);
        gsap
          .timeline()
          .to(numRef.current, {
            scale: 1.4,
            opacity: 0,
            duration: 0.4,
            ease: 'power3.in',
          })
          .to(
            [logoRef.current, txtRef.current, barRef.current],
            {
              opacity: 0,
              y: -20,
              duration: 0.4,
              stagger: 0.05,
              ease: 'power3.in',
            },
            '<'
          )
          .to(
            wrapRef.current,
            {
              opacity: 0,
              duration: 0.6,
              ease: 'power3.inOut',
              onComplete,
            },
            '+=0.15'
          )
          .set(wrapRef.current, { display: 'none' });
      }
    }, 120);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div
      ref={wrapRef}
      className="fixed inset-0 z-[200000] bg-black flex flex-col items-center justify-center"
    >
      {/* Subtle gold beam in background */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          background:
            'radial-gradient(ellipse at center, rgba(200,165,92,0.15), transparent 60%)',
        }}
      />

      <div ref={logoRef} className="mb-12 text-center">
        <div className="font-mono text-[10px] tracking-[0.4em] text-gold/60 mb-3 uppercase">
          A Shukurat Damilola Rasak production
        </div>
        <div className="font-display text-5xl tracking-tight text-white/90">SDR</div>
      </div>

      <div
        ref={numRef}
        className="font-mono text-5xl font-light text-gold mb-8 tabular-nums"
        style={{ letterSpacing: '0.05em' }}
      >
        {pct.toString().padStart(2, '0')}%
      </div>

      <div
        ref={barRef}
        className="h-px bg-gradient-to-r from-transparent via-gold to-transparent"
        style={{ width: 0 }}
      />

      <div
        ref={txtRef}
        className="font-mono text-[10px] tracking-[0.35em] text-gold/40 mt-8 uppercase opacity-0"
      >
        Initializing dimension
      </div>
    </div>
  );
}
