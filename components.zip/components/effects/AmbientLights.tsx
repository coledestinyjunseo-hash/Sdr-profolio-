'use client';

import { useEffect, useRef } from 'react';
import { gsap } from '@/lib/gsap';

interface Orb {
  size: number;
  color: string;
  startX: string;
  startY: string;
  blur: number;
  parallax: number;
}

const ORBS: Orb[] = [
  { size: 700, color: 'rgba(200,165,92,0.08)', startX: '-15%', startY: '-20%', blur: 110, parallax: 0.15 },
  { size: 500, color: 'rgba(0,229,255,0.05)', startX: '90%', startY: '50%', blur: 100, parallax: 0.25 },
  { size: 450, color: 'rgba(139,92,246,0.06)', startX: '20%', startY: '110%', blur: 110, parallax: 0.2 },
  { size: 380, color: 'rgba(236,72,153,0.04)', startX: '70%', startY: '85%', blur: 90, parallax: 0.18 },
];

export default function AmbientLights() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const orbs = Array.from(el.children) as HTMLElement[];
    const targets = orbs.map(() => ({ x: 0, y: 0 }));
    const current = orbs.map(() => ({ x: 0, y: 0 }));

    const onMove = (e: MouseEvent) => {
      const nx = e.clientX / window.innerWidth - 0.5;
      const ny = e.clientY / window.innerHeight - 0.5;
      orbs.forEach((_, i) => {
        const factor = ORBS[i]?.parallax ?? 0.2;
        targets[i].x = nx * 120 * factor;
        targets[i].y = ny * 120 * factor;
      });
    };

    let raf = 0;
    const tick = () => {
      orbs.forEach((o, i) => {
        current[i].x += (targets[i].x - current[i].x) * 0.05;
        current[i].y += (targets[i].y - current[i].y) * 0.05;
        o.style.transform = `translate3d(${current[i].x}px, ${current[i].y}px, 0)`;
      });
      raf = requestAnimationFrame(tick);
    };

    // Slow float drift
    orbs.forEach((o, i) => {
      gsap.to(o, {
        scale: 1.15,
        duration: 8 + i * 1.5,
        ease: 'sine.inOut',
        repeat: -1,
        yoyo: true,
        delay: i * 0.5,
      });
    });

    window.addEventListener('mousemove', onMove);
    raf = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener('mousemove', onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div ref={ref} aria-hidden className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
      {ORBS.map((orb, i) => (
        <div
          key={i}
          className="absolute rounded-full will-change-transform"
          style={{
            width: orb.size,
            height: orb.size,
            background: orb.color,
            filter: `blur(${orb.blur}px)`,
            left: orb.startX,
            top: orb.startY,
            transform: 'translate(-50%, -50%)',
          }}
        />
      ))}
    </div>
  );
}
