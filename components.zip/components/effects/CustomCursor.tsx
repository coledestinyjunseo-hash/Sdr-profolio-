'use client';

import { useEffect, useRef } from 'react';
import { gsap } from '@/lib/gsap';
import { isTouchDevice } from '@/lib/utils';

export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isTouchDevice()) return;

    document.documentElement.classList.add('has-custom-cursor');

    const dot = dotRef.current!;
    const ring = ringRef.current!;
    const glow = glowRef.current!;

    const setDotX = gsap.quickSetter(dot, 'x', 'px');
    const setDotY = gsap.quickSetter(dot, 'y', 'px');
    const setRingX = gsap.quickTo(ring, 'x', { duration: 0.4, ease: 'power3.out' });
    const setRingY = gsap.quickTo(ring, 'y', { duration: 0.4, ease: 'power3.out' });
    const setGlowX = gsap.quickTo(glow, 'x', { duration: 0.9, ease: 'power3.out' });
    const setGlowY = gsap.quickTo(glow, 'y', { duration: 0.9, ease: 'power3.out' });

    const onMove = (e: MouseEvent) => {
      setDotX(e.clientX);
      setDotY(e.clientY);
      setRingX(e.clientX);
      setRingY(e.clientY);
      setGlowX(e.clientX);
      setGlowY(e.clientY);
    };

    const onEnter = () => {
      ring.classList.add('cursor-active');
      gsap.to(ring, { scale: 1.6, borderColor: '#00e5ff', duration: 0.4, ease: 'power3.out' });
      gsap.to(dot, { scale: 0.4, duration: 0.4, ease: 'power3.out' });
    };
    const onLeave = () => {
      ring.classList.remove('cursor-active');
      gsap.to(ring, { scale: 1, borderColor: 'rgba(200,165,92,0.4)', duration: 0.4, ease: 'power3.out' });
      gsap.to(dot, { scale: 1, duration: 0.4, ease: 'power3.out' });
    };

    document.addEventListener('mousemove', onMove);

    const hoverables = document.querySelectorAll(
      'a, button, [data-cursor="hover"], .glass-hover, input, textarea'
    );
    hoverables.forEach((el) => {
      el.addEventListener('mouseenter', onEnter);
      el.addEventListener('mouseleave', onLeave);
    });

    // Reattach on DOM changes (for dynamically rendered content)
    const observer = new MutationObserver(() => {
      document
        .querySelectorAll('a, button, [data-cursor="hover"], .glass-hover')
        .forEach((el) => {
          el.removeEventListener('mouseenter', onEnter);
          el.removeEventListener('mouseleave', onLeave);
          el.addEventListener('mouseenter', onEnter);
          el.addEventListener('mouseleave', onLeave);
        });
    });
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      document.removeEventListener('mousemove', onMove);
      hoverables.forEach((el) => {
        el.removeEventListener('mouseenter', onEnter);
        el.removeEventListener('mouseleave', onLeave);
      });
      observer.disconnect();
      document.documentElement.classList.remove('has-custom-cursor');
    };
  }, []);

  if (typeof window !== 'undefined' && isTouchDevice()) return null;

  return (
    <>
      <div
        ref={dotRef}
        className="fixed pointer-events-none z-[99999] w-2 h-2 bg-gold rounded-full mix-blend-difference"
        style={{ transform: 'translate(-50%, -50%)', top: 0, left: 0, willChange: 'transform' }}
      />
      <div
        ref={ringRef}
        className="fixed pointer-events-none z-[99998] w-10 h-10 rounded-full border border-gold/40"
        style={{ transform: 'translate(-50%, -50%)', top: 0, left: 0, willChange: 'transform' }}
      />
      <div
        ref={glowRef}
        className="fixed pointer-events-none z-[1] w-[500px] h-[500px] rounded-full"
        style={{
          background:
            'radial-gradient(circle, rgba(200,165,92,0.06), transparent 70%)',
          transform: 'translate(-50%, -50%)',
          top: 0,
          left: 0,
          willChange: 'transform',
        }}
      />
    </>
  );
}
