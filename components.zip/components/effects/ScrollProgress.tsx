'use client';

import { useEffect, useRef } from 'react';
import { gsap, ScrollTrigger } from '@/lib/gsap';

export default function ScrollProgress() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;
    const tween = gsap.to(ref.current, {
      width: '100%',
      ease: 'none',
      scrollTrigger: {
        trigger: document.body,
        start: 'top top',
        end: 'bottom bottom',
        scrub: true,
      },
    });
    return () => {
      tween.scrollTrigger?.kill();
      tween.kill();
    };
  }, []);

  return (
    <div
      ref={ref}
      className="fixed top-0 left-0 h-[2px] w-0 z-[10000]"
      style={{
        background: 'linear-gradient(90deg, #c8a55c, #00e5ff, #8b5cf6)',
        boxShadow: '0 0 12px rgba(200,165,92,0.6)',
      }}
    />
  );
}
