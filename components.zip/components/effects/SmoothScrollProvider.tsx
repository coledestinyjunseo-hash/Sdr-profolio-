'use client';

import { useLenis } from '@/hooks/useLenis';
import { useEffect } from 'react';
import { ScrollTrigger } from '@/lib/gsap';

export default function SmoothScrollProvider({ children }: { children: React.ReactNode }) {
  useLenis();
  useEffect(() => {
    // Refresh ScrollTrigger after mount once Lenis is wired
    const t = setTimeout(() => ScrollTrigger.refresh(), 300);
    return () => clearTimeout(t);
  }, []);
  return <>{children}</>;
}
