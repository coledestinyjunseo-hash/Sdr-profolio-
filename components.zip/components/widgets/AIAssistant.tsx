'use client';

import { useEffect, useRef, useState } from 'react';
import { Sparkles, X } from 'lucide-react';
import { gsap } from '@/lib/gsap';
import { AI_INSIGHTS } from '@/lib/constants';

interface Message {
  id: number;
  text: string;
  typing?: boolean;
}

let nextId = 1;

export default function AIAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const chatRef = useRef<HTMLDivElement>(null);
  const idxRef = useRef(0);

  useEffect(() => {
    if (!chatRef.current) return;
    if (open) {
      gsap.fromTo(
        chatRef.current,
        { y: 20, scale: 0.94, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, duration: 0.45, ease: 'back.out(1.4)' }
      );
      if (messages.length === 0) {
        addMessage('Systems online. Monitoring your digital universe...');
      }
    } else {
      gsap.to(chatRef.current, {
        y: 20,
        scale: 0.94,
        opacity: 0,
        duration: 0.3,
        ease: 'power3.in',
      });
    }
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const addMessage = (text: string) => {
    const typingId = nextId++;
    setMessages((prev) => [...prev, { id: typingId, text: '', typing: true }]);
    setTimeout(() => {
      setMessages((prev) =>
        prev.map((m) => (m.id === typingId ? { id: typingId, text } : m))
      );
    }, 1100);
  };

  // Periodically push new insights
  useEffect(() => {
    if (!open) return;
    const id = setInterval(() => {
      addMessage(AI_INSIGHTS[idxRef.current % AI_INSIGHTS.length]);
      idxRef.current++;
    }, 7500);
    return () => clearInterval(id);
  }, [open]);

  return (
    <div className="fixed bottom-6 right-6 z-[9500] hidden md:block">
      <div
        ref={chatRef}
        className="absolute bottom-[70px] right-0 w-[340px] max-h-[420px] overflow-y-auto rounded-3xl p-6 opacity-0"
        style={{
          background: 'rgba(10,10,18,0.95)',
          backdropFilter: 'blur(30px)',
          border: '1px solid rgba(200,165,92,0.2)',
          pointerEvents: open ? 'auto' : 'none',
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="font-mono text-[11px] tracking-[0.12em] text-gold flex items-center gap-2">
            <span className="pulse-dot" /> SDR STRATEGY AI
          </div>
          <button onClick={() => setOpen(false)} aria-label="Close">
            <X className="w-4 h-4 text-white/40 hover:text-gold transition-colors" />
          </button>
        </div>
        <div className="flex flex-col gap-2">
          {messages.map((m) => (
            <div
              key={m.id}
              className="px-3.5 py-2.5 bg-white/[0.03] rounded-xl text-[13px] text-white/65 leading-relaxed"
            >
              {m.typing ? (
                <div className="flex gap-1 py-1">
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-gold"
                    style={{ animation: 'tdot 1.4s infinite' }}
                  />
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-gold"
                    style={{ animation: 'tdot 1.4s infinite 0.2s' }}
                  />
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-gold"
                    style={{ animation: 'tdot 1.4s infinite 0.4s' }}
                  />
                </div>
              ) : (
                m.text
              )}
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={() => setOpen((o) => !o)}
        className="ml-auto w-14 h-14 rounded-full flex items-center justify-center cursor-pointer transition-transform hover:scale-105 active:scale-95"
        style={{
          background: 'linear-gradient(135deg, #c8a55c, #d4a853)',
          boxShadow: '0 8px 30px rgba(200,165,92,0.4)',
        }}
        aria-label="Open AI Assistant"
      >
        <Sparkles className="w-6 h-6 text-black" strokeWidth={2} />
      </button>
    </div>
  );
}
