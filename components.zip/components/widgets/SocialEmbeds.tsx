'use client';

import { useEffect, useRef, useState } from 'react';
import Script from 'next/script';

interface TikTokEmbedProps {
  /** Full TikTok video URL */
  url: string;
  /** Optional caption */
  caption?: string;
}

export function TikTokEmbed({ url, caption }: TikTokEmbedProps) {
  const videoId = url.split('/').pop()?.split('?')[0] ?? '';
  return (
    <div className="w-full max-w-[325px] mx-auto">
      <blockquote
        className="tiktok-embed"
        cite={url}
        data-video-id={videoId}
        style={{ maxWidth: 325, minWidth: 280 }}
      >
        <section>
          {caption && <p className="text-white/40 text-sm p-4">{caption}</p>}
        </section>
      </blockquote>
      <Script async src="https://www.tiktok.com/embed.js" strategy="lazyOnload" />
    </div>
  );
}

interface InstagramEmbedProps {
  url: string;
}

export function InstagramEmbed({ url }: InstagramEmbedProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!loaded) return;
    const win = window as Window & { instgrm?: { Embeds: { process: () => void } } };
    if (win.instgrm?.Embeds) {
      win.instgrm.Embeds.process();
    }
  }, [loaded, url]);

  return (
    <div ref={containerRef} className="w-full max-w-[400px] mx-auto">
      <blockquote
        className="instagram-media"
        data-instgrm-permalink={url}
        data-instgrm-version="14"
        style={{
          background: 'transparent',
          border: 0,
          margin: '1px',
          maxWidth: 540,
          minWidth: 280,
          padding: 0,
          width: '99.375%',
        }}
      />
      <Script
        async
        src="https://www.instagram.com/embed.js"
        strategy="lazyOnload"
        onLoad={() => setLoaded(true)}
      />
    </div>
  );
}
