'use client';

import { useEffect, useState, useRef } from 'react';
import { gsap } from '@/lib/gsap';
import { LIVE_NOTIFICATIONS } from '@/lib/constants';

interface Notification {
  id: number;
  color: string;
  text: string;
  time: string;
}

let nextId = 1;

export default function NotificationFeed() {
  const [items, setItems] = useState<Notification[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const id = setInterval(() => {
      const notif = LIVE_NOTIFICATIONS[Math.floor(Math.random() * LIVE_NOTIFICATIONS.length)];
      const newItem: Notification = { id: nextId++, ...notif };
      setItems((prev) => [...prev, newItem]);
      setTimeout(() => {
        setItems((prev) => prev.filter((i) => i.id !== newItem.id));
      }, 4800);
    }, 9000);
    return () => clearInterval(id);
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed bottom-6 left-6 z-[9500] hidden md:flex flex-col gap-2.5 max-w-[340px]"
    >
      {items.map((item) => (
        <NotifCard key={item.id} {...item} />
      ))}
    </div>
  );
}

function NotifCard({ color, text, time }: Omit<Notification, 'id'>) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    gsap.fromTo(
      ref.current,
      { x: -40, opacity: 0 },
      { x: 0, opacity: 1, duration: 0.5, ease: 'power3.out' }
    );
    return () => {
      if (ref.current) {
        gsap.to(ref.current, { x: -40, opacity: 0, duration: 0.4 });
      }
    };
  }, []);

  return (
    <div
      ref={ref}
      className="px-5 py-3.5 rounded-2xl flex items-center gap-3 opacity-0"
      style={{
        background: 'rgba(255,255,255,0.06)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(255,255,255,0.08)',
        boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
      }}
    >
      <div
        className="w-2 h-2 rounded-full flex-shrink-0"
        style={{ background: color, boxShadow: `0 0 12px ${color}` }}
      />
      <div className="min-w-0">
        <div className="text-xs text-white/80">{text}</div>
        <div className="text-[10px] text-white/30 mt-0.5">{time}</div>
      </div>
    </div>
  );
}
