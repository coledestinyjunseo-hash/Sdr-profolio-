'use client';

import { useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import { gsap, ScrollTrigger } from '@/lib/gsap';
import { ANALYTICS } from '@/lib/constants';
import GlassCard from '@/components/ui/GlassCard';

function formatLive(n: number) {
  return n.toLocaleString('en-US');
}

export default function Analytics() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<HTMLDivElement>(null);

  const [views, setViews] = useState(2_412_847);
  const [followers, setFollowers] = useState(347_291);

  // Entrance animations
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.dash-wrap', {
        y: 70,
        opacity: 0,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
          toggleActions: 'play none none reverse',
        },
      });
      gsap.from('.dash-metric', {
        y: 30,
        opacity: 0,
        scale: 0.96,
        stagger: 0.08,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: '.dash-metric-grid',
          start: 'top 85%',
          toggleActions: 'play none none reverse',
        },
      });

      // Chart bars
      const bars = gsap.utils.toArray<HTMLElement>('.chart-bar');
      bars.forEach((bar, i) => {
        gsap.fromTo(
          bar,
          { height: 0 },
          {
            height: bar.dataset.height,
            duration: 1.1,
            delay: i * 0.06,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: chartRef.current,
              start: 'top 88%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });

      // Territory bars
      gsap.utils.toArray<HTMLElement>('.territory-row').forEach((row, i) => {
        gsap.from(row, {
          opacity: 0,
          x: 30,
          duration: 0.6,
          delay: i * 0.08,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: row,
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          },
        });
      });
    }, sectionRef);
    return () => {
      ctx.revert();
      ScrollTrigger.refresh();
    };
  }, []);

  // Live ticker
  useEffect(() => {
    const id = setInterval(() => {
      setViews((v) => v + Math.floor(Math.random() * 150) + 20);
      setFollowers((f) => f + Math.floor(Math.random() * 5));
    }, 3000);
    return () => clearInterval(id);
  }, []);

  const chartMax = Math.max(...ANALYTICS.chart);

  return (
    <section
      id="analytics"
      ref={sectionRef}
      className="relative z-10 py-24 md:py-32 px-6 md:px-10"
    >
      <div className="max-w-[1200px] mx-auto">
        <div className="section-label">[ Analytics ]</div>
        <h2 className="section-title">
          Performance
          <br />
          <span className="italic font-light bg-gradient-to-r from-gold to-gold-300 bg-clip-text text-transparent">
            Engine
          </span>
        </h2>

        <GlassCard className="dash-wrap mt-10 p-7 md:p-10 relative" hover={false}>
          {/* macOS chrome */}
          <div className="absolute top-3 left-5 flex gap-2 z-10">
            <span className="w-3 h-3 rounded-full bg-[#ff5f57]" />
            <span className="w-3 h-3 rounded-full bg-[#febc2e]" />
            <span className="w-3 h-3 rounded-full bg-[#28c840]" />
          </div>

          {/* Topbar */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 mb-6 pt-6 border-b border-white/[0.06] pb-5">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Image
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop&q=85"
                  alt="Profile"
                  width={36}
                  height={36}
                  className="rounded-full border-2 border-gold object-cover"
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-green-500 border-2 border-bg" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-semibold text-sm">Shukurat Rasak</span>
                  <span className="bg-gold/10 border border-gold/20 rounded-full px-2 py-0.5 text-[9px] text-gold">
                    ✓ Verified
                  </span>
                </div>
                <div className="text-[11px] text-white/30">@shukuratrasak</div>
              </div>
            </div>
            <div className="flex gap-3 items-center">
              <span className="pulse-dot" />
              <span className="text-[11px] text-white/30">Live</span>
              <select className="bg-white/[0.03] border border-white/[0.06] text-white/50 px-3 py-1.5 rounded-lg text-[11px] outline-none cursor-pointer">
                <option>Last 90 days</option>
                <option>Last 30 days</option>
                <option>Last 7 days</option>
              </select>
            </div>
          </div>

          {/* Metrics */}
          <div className="dash-metric-grid grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            <MetricCard
              live
              label="Live Views"
              value={formatLive(views)}
              change="+142.3%"
            />
            <MetricCard label="Profile Visits" value="89.7K" change="+87.5%" />
            <MetricCard label="Followers" value={formatLive(followers)} change="+23.8%" />
            <MetricCard label="Engagement" value="8.7%" change="+34.1%" />
          </div>

          {/* Chart + territories */}
          <div className="grid md:grid-cols-3 gap-4 mt-4">
            <div className="glass md:col-span-2 p-6 md:p-7 rounded-2xl border-none bg-white/[0.02]">
              <div className="font-mono text-[10px] tracking-widest uppercase text-white/30 mb-5">
                Video Views — 12 Months
              </div>
              <div ref={chartRef} className="flex items-end gap-2 h-40">
                {ANALYTICS.chart.map((v, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
                    <div
                      className="chart-bar w-full rounded-t-md min-h-[4px]"
                      data-height={`${(v / chartMax) * 100}%`}
                      style={{
                        background:
                          'linear-gradient(to top, rgba(254,44,85,0.4), rgba(200,165,92,0.85))',
                        boxShadow: '0 -4px 12px rgba(200,165,92,0.15)',
                      }}
                    />
                    <span className="text-[8px] font-mono text-white/20">
                      {['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'][i]}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass p-6 md:p-7 rounded-2xl border-none bg-white/[0.02]">
              <div className="font-mono text-[10px] tracking-widest uppercase text-white/30 mb-5">
                Top Territories
              </div>
              <div className="flex flex-col gap-3">
                {ANALYTICS.territories.map((t) => (
                  <div
                    key={t.name}
                    className="territory-row flex justify-between items-center text-xs"
                  >
                    <span className="text-white/45 flex items-center gap-1.5">
                      <span className="text-base leading-none">{t.flag}</span>
                      {t.name}
                    </span>
                    <span className="text-gold font-mono font-semibold tabular-nums">
                      {t.pct}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Top Content */}
          <div className="glass mt-4 p-6 md:p-7 rounded-2xl border-none bg-white/[0.02]">
            <div className="font-mono text-[10px] tracking-widest uppercase text-white/30 mb-5">
              Top Content
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              {ANALYTICS.topContent.map((item) => (
                <div
                  key={item.title}
                  className="flex gap-4 items-center p-3 rounded-xl hover:bg-white/[0.03] transition-colors cursor-pointer"
                >
                  <div className="relative w-14 h-[72px] rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src={item.image}
                      alt={item.title}
                      fill
                      sizes="56px"
                      className="object-cover"
                    />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{item.title}</div>
                    <div className="text-[10px] text-white/20 mt-0.5">{item.time}</div>
                    <div className="flex gap-3 mt-1 text-[11px] text-white/40 font-mono">
                      <span>▶ {item.views}</span>
                      <span>♥ {item.likes}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </GlassCard>
      </div>
    </section>
  );
}

function MetricCard({
  label,
  value,
  change,
  live = false,
}: {
  label: string;
  value: string;
  change: string;
  live?: boolean;
}) {
  return (
    <div className="dash-metric glass p-5 md:p-6 rounded-2xl relative overflow-hidden border-none bg-white/[0.025]">
      <div className="absolute top-0 left-0 right-0 h-px overflow-hidden">
        <div
          className="h-full w-full animate-scan-line"
          style={{
            background:
              'linear-gradient(90deg, transparent, rgba(200,165,92,0.5), transparent)',
          }}
        />
      </div>
      <div className="flex items-center gap-2 mb-2.5">
        {live && <span className="pulse-dot" />}
        <span className="font-mono text-[10px] tracking-widest uppercase text-white/30">
          {label}
        </span>
      </div>
      <div className="font-mono text-2xl md:text-3xl font-bold tabular-nums">{value}</div>
      <div className="text-[11px] text-green-500 mt-1.5">↑ {change}</div>
    </div>
  );
}
