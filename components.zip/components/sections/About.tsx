'use client';

import { useEffect, useRef } from 'react';
import Image from 'next/image';
import { gsap } from '@/lib/gsap';
import { SITE, STATS } from '@/lib/constants';
import GlassCard from '@/components/ui/GlassCard';
import AnimatedCounter from '@/components/ui/AnimatedCounter';

export default function About() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLDivElement>(null);
  const txtRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(imgRef.current, {
        x: -80,
        opacity: 0,
        rotateY: 10,
        duration: 1.3,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 70%',
          toggleActions: 'play none none reverse',
        },
      });
      gsap.from(txtRef.current, {
        x: 80,
        opacity: 0,
        rotateY: -10,
        duration: 1.3,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 70%',
          toggleActions: 'play none none reverse',
        },
      });

      // 3D parallax for image
      gsap.to(imgRef.current, {
        y: -60,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1.5,
        },
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative z-10 py-24 md:py-32 px-6 md:px-10"
    >
      <div className="max-w-[1200px] mx-auto grid md:grid-cols-2 gap-12 md:gap-20 items-center">
        <div ref={imgRef} className="relative" style={{ perspective: 1000 }}>
          <GlassCard className="p-5" tilt intensity={6}>
            <div className="relative aspect-[3/4] overflow-hidden rounded-2xl">
              <Image
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=900&h=1200&fit=crop&q=85"
                alt="Shukurat Damilola Rasak — Portrait"
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
              />
              {/* Edge sheen */}
              <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-black/30 via-transparent to-gold/10 mix-blend-overlay" />
            </div>
          </GlassCard>
          {/* Floating accent */}
          <div
            className="absolute -top-4 -right-4 w-24 h-24 rounded-full pointer-events-none animate-float-slow"
            style={{
              background: 'radial-gradient(circle, rgba(200,165,92,0.4), transparent)',
              filter: 'blur(30px)',
            }}
          />
        </div>

        <div ref={txtRef} style={{ perspective: 1000 }}>
          <div className="section-label">[ About ]</div>
          <h2 className="section-title text-balance">
            Crafting
            <br />
            <span className="italic font-light bg-gradient-to-r from-gold-200 via-gold to-gold-200 bg-clip-text text-transparent">
              Digital Empires
            </span>
          </h2>
          <p className="section-sub mb-10">{SITE.description}</p>

          <div className="grid grid-cols-2 gap-3 md:gap-4">
            {STATS.map((stat, i) => (
              <GlassCard
                key={i}
                tilt
                className="p-5 md:p-6 text-center cursor-pointer relative overflow-hidden group"
              >
                <div className="font-mono text-3xl md:text-4xl font-bold text-gold tabular-nums">
                  <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-[11px] tracking-wider text-white/35 mt-1 uppercase">
                  {stat.label}
                </div>
                {/* Hover sheen */}
                <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/[0.04] to-transparent group-hover:translate-x-full transition-transform duration-1000 pointer-events-none" />
              </GlassCard>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
