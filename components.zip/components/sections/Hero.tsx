'use client';

import { useEffect, useRef } from 'react';
import Image from 'next/image';
import { gsap, ScrollTrigger } from '@/lib/gsap';
import { SITE } from '@/lib/constants';
import { scrollToSection } from '@/hooks/useLenis';
import MagneticButton from '@/components/ui/MagneticButton';

interface HeroProps {
  startAnimation: boolean;
}

export default function Hero({ startAnimation }: HeroProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const pinRef = useRef<HTMLDivElement>(null);
  const n1Ref = useRef<HTMLSpanElement>(null);
  const n2Ref = useRef<HTMLSpanElement>(null);
  const n3Ref = useRef<HTMLSpanElement>(null);
  const eyeRef = useRef<HTMLDivElement>(null);
  const subRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const m1Ref = useRef<HTMLDivElement>(null);
  const m2Ref = useRef<HTMLDivElement>(null);

  // Entrance
  useEffect(() => {
    if (!startAnimation) return;
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });
      tl.to(eyeRef.current, { opacity: 1, duration: 1, delay: 0.2 })
        .to(n1Ref.current, { y: 0, duration: 1.1, ease: 'power4.out' }, '-=0.6')
        .to(n2Ref.current, { y: 0, duration: 1.1, ease: 'power4.out' }, '-=0.85')
        .to(n3Ref.current, { y: 0, duration: 1.1, ease: 'power4.out' }, '-=0.85')
        .to(subRef.current, { opacity: 1, duration: 1 }, '-=0.5')
        .to(ctaRef.current, { opacity: 1, y: 0, duration: 1 }, '-=0.6')
        .to(scrollRef.current, { opacity: 1, duration: 0.8 }, '-=0.4')
        .to(
          m1Ref.current,
          { opacity: 1, x: 0, rotateY: -14, duration: 1.4, ease: 'power3.out' },
          '-=1.1'
        )
        .to(
          m2Ref.current,
          { opacity: 1, x: 0, rotateY: 14, duration: 1.4, ease: 'power3.out' },
          '-=1.4'
        );
    }, sectionRef);
    return () => ctx.revert();
  }, [startAnimation]);

  // Scroll pinning + parallax
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Pin & zoom-fade
      gsap.to(pinRef.current, {
        scale: 1.35,
        opacity: 0,
        filter: 'blur(10px)',
        y: -80,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=1100',
          scrub: 1.4,
          pin: true,
          anticipatePin: 1,
        },
      });

      // Mockups depart with depth
      gsap.to(m1Ref.current, {
        z: -500,
        rotateY: -45,
        y: -240,
        opacity: 0,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=1100',
          scrub: 2,
        },
      });
      gsap.to(m2Ref.current, {
        z: -500,
        rotateY: 45,
        y: 240,
        opacity: 0,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=1100',
          scrub: 2,
        },
      });

      gsap.to(scrollRef.current, {
        opacity: 0,
        y: -20,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '200 top',
          scrub: true,
        },
      });
    }, sectionRef);
    return () => {
      ctx.revert();
      ScrollTrigger.getAll().forEach((t) => {
        if (t.trigger === sectionRef.current) t.kill();
      });
    };
  }, []);

  return (
    <section
      id="hero"
      ref={sectionRef}
      className="relative h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Video background */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <video
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
          className="w-full h-full object-cover opacity-25"
          style={{ filter: 'blur(6px) brightness(0.5) saturate(1.5)' }}
        >
          <source
            src="https://videos.pexels.com/video-files/3571264/3571264-uhd_2560_1440_25fps.mp4"
            type="video/mp4"
          />
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-bg/70 via-bg/40 to-bg/90" />
      </div>

      {/* Phone mockup left */}
      <div
        ref={m1Ref}
        className="mockup absolute hidden md:block"
        style={{
          top: '12%',
          left: '4%',
          transform: 'translateX(-80px)',
        }}
      >
        <div className="mockup-inner">
          <div className="mockup-notch" />
          <Image
            src="https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=440&h=880&fit=crop&q=85"
            alt="Mobile app preview"
            width={220}
            height={440}
            priority
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Phone mockup right */}
      <div
        ref={m2Ref}
        className="mockup absolute hidden md:block"
        style={{
          top: '15%',
          right: '4%',
          transform: 'translateX(80px)',
        }}
      >
        <div className="mockup-inner">
          <div className="mockup-notch" />
          <Image
            src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=440&h=880&fit=crop&q=85"
            alt="Dashboard analytics preview"
            width={220}
            height={440}
            priority
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Centerpiece — pinned content */}
      <div ref={pinRef} className="relative z-10 text-center px-5 max-w-5xl">
        <div
          ref={eyeRef}
          className="font-mono text-[11px] tracking-[0.4em] uppercase text-gold mb-7 opacity-0"
        >
          {SITE.role}
        </div>

        <h1 className="font-display font-medium tracking-tight leading-[0.95] mb-7">
          <span className="text-reveal-mask block text-[clamp(40px,9vw,118px)]">
            <span ref={n1Ref} className="text-reveal-inner block">
              SHUKURAT
            </span>
          </span>
          <span className="text-reveal-mask block text-[clamp(40px,9vw,118px)]">
            <span
              ref={n2Ref}
              className="text-reveal-inner block bg-gradient-to-r from-gold via-gold-200 to-gold bg-clip-text text-transparent"
            >
              DAMILOLA
            </span>
          </span>
          <span className="text-reveal-mask block text-[clamp(40px,9vw,118px)]">
            <span ref={n3Ref} className="text-reveal-inner block">
              RASAK
            </span>
          </span>
        </h1>

        <p
          ref={subRef}
          className="font-mono text-[clamp(11px,1.4vw,15px)] tracking-[0.25em] uppercase text-white/45 mb-11 opacity-0"
        >
          {SITE.tagline}
        </p>

        <div
          ref={ctaRef}
          className="flex gap-4 justify-center flex-wrap opacity-0 translate-y-4"
        >
          <MagneticButton onClick={() => scrollToSection('contact')}>
            Begin Collaboration
          </MagneticButton>
          <MagneticButton variant="secondary" onClick={() => scrollToSection('portfolio')}>
            View Work
          </MagneticButton>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        ref={scrollRef}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-0"
      >
        <span className="font-mono text-[9px] tracking-[0.3em] uppercase text-white/25">
          Scroll
        </span>
        <div className="w-px h-10 bg-gradient-to-b from-gold to-transparent" />
      </div>
    </section>
  );
}
