'use client';

import { useEffect, useRef, useState } from 'react';
import { Phone, Mail, ArrowUpRight } from 'lucide-react';
import { gsap } from '@/lib/gsap';
import { SITE } from '@/lib/constants';
import GlassCard from '@/components/ui/GlassCard';
import MagneticButton from '@/components/ui/MagneticButton';
import { useToast } from '@/components/ui/Toast';

export default function Contact() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const { showToast } = useToast();
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(panelRef.current, {
        scale: 0.94,
        opacity: 0,
        y: 40,
        duration: 1.1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: panelRef.current,
          start: 'top 85%',
          toggleActions: 'play none none reverse',
        },
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      showToast('Message sent successfully ✨');
      formRef.current?.reset();
      setSubmitting(false);
    }, 600);
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative z-10 py-24 md:py-32 px-6 md:px-10"
    >
      <div className="max-w-[820px] mx-auto text-center">
        <div className="section-label">[ Contact ]</div>
        <h2 className="section-title">
          Let&apos;s Build
          <br />
          <span className="italic font-light bg-gradient-to-r from-gold-200 to-gold bg-clip-text text-transparent">
            Something Iconic
          </span>
        </h2>
      </div>

      <div className="max-w-[820px] mx-auto mt-12">
        <GlassCard ref={panelRef} className="p-8 md:p-14 relative overflow-hidden" hover={false}>
          {/* Decorative gradient */}
          <div
            className="absolute -top-20 -right-20 w-80 h-80 rounded-full opacity-30 pointer-events-none"
            style={{
              background: 'radial-gradient(circle, rgba(200,165,92,0.3), transparent 70%)',
              filter: 'blur(60px)',
            }}
          />

          <form ref={formRef} onSubmit={handleSubmit} className="relative">
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <Input name="name" placeholder="Your Name" required />
              <Input type="email" name="email" placeholder="Your Email" required />
            </div>
            <Textarea name="message" placeholder="Tell me about your vision..." required />
            <MagneticButton
              type="submit"
              disabled={submitting}
              className="w-full justify-center mt-5"
            >
              {submitting ? 'Sending…' : 'Send Message'}
            </MagneticButton>
          </form>

          <div className="flex flex-col sm:flex-row gap-3 mt-8">
            <ContactLink
              href={SITE.phoneHref}
              icon={Phone}
              label="Phone"
              value={SITE.phone}
            />
            <ContactLink
              href={`mailto:${SITE.email}`}
              icon={Mail}
              label="Email"
              value={SITE.email}
            />
          </div>
        </GlassCard>
      </div>
    </section>
  );
}

function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className="w-full px-5 py-4 bg-white/[0.03] border border-white/[0.06] rounded-2xl text-white text-sm outline-none transition-colors focus:border-gold/40 placeholder:text-white/20"
    />
  );
}

function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className="w-full px-5 py-4 bg-white/[0.03] border border-white/[0.06] rounded-2xl text-white text-sm outline-none transition-colors focus:border-gold/40 placeholder:text-white/20 resize-y min-h-[140px]"
    />
  );
}

interface ContactLinkProps {
  href: string;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  label: string;
  value: string;
}

function ContactLink({ href, icon: Icon, label, value }: ContactLinkProps) {
  return (
    <a
      href={href}
      className="glass glass-hover flex-1 px-6 py-4 flex items-center gap-4 group"
    >
      <div className="w-10 h-10 rounded-xl bg-gold/10 flex items-center justify-center group-hover:bg-gold/20 transition-colors">
        <Icon className="w-4 h-4 text-gold" strokeWidth={1.5} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-[10px] text-white/30 uppercase tracking-[0.18em]">{label}</div>
        <div className="text-sm text-white/80 mt-0.5 truncate">{value}</div>
      </div>
      <ArrowUpRight
        className="w-4 h-4 text-white/30 group-hover:text-gold group-hover:rotate-45 transition-all"
        strokeWidth={1.5}
      />
    </a>
  );
}
