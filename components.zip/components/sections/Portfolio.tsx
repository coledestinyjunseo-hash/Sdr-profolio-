'use client';

import { useEffect, useRef } from 'react';
import Image from 'next/image';
import { gsap, ScrollTrigger } from '@/lib/gsap';
import { PORTFOLIO } from '@/lib/constants';
import { cn } from '@/lib/utils';

const accentMap: Record<string, string> = {
  gold: 'text-gold',
  tiktok: 'text-[#fe2c55]',
  ig: 'text-[#e1306c]',
};

export default function Portfolio() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const panels = gsap.utils.toArray<HTMLElement>('.portfolio-panel');
      const totalDistance = (panels.length - 1) * window.innerWidth;

      const tween = gsap.to(panels, {
        xPercent: -100 * (panels.length - 1),
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          pin: true,
          scrub: 1.2,
          end: () => `+=${totalDistance}`,
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });

      // Parallax on each card image
      panels.forEach((panel) => {
        const img = panel.querySelector('.portfolio-image');
        const caption = panel.querySelector('.portfolio-caption');
        if (!img || !caption) return;

        gsap.fromTo(
          img,
          { scale: 1.1 },
          {
            scale: 1,
            ease: 'none',
            scrollTrigger: {
              trigger: panel,
              containerAnimation: tween,
              start: 'left right',
              end: 'right left',
              scrub: 1,
            },
          }
        );
        gsap.fromTo(
          caption,
          { y: 60, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            ease: 'power2.out',
            duration: 1.2,
            scrollTrigger: {
              trigger: panel,
              containerAnimation: tween,
              start: 'left 70%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });
    }, sectionRef);

    const refresh = () => ScrollTrigger.refresh();
    window.addEventListener('resize', refresh);

    return () => {
      window.removeEventListener('resize', refresh);
      ctx.revert();
    };
  }, []);

  return (
    <section
      id="portfolio"
      ref={sectionRef}
      className="relative z-10 overflow-hidden h-screen"
    >
      {/* Title overlay */}
      <div className="absolute top-1/2 left-[5vw] -translate-y-1/2 z-20 pointer-events-none max-w-md">
        <div className="section-label">[ Portfolio ]</div>
        <h2 className="section-title">
          Selected
          <br />
          <span className="italic font-light">Works</span>
        </h2>
        <p className="font-mono text-[11px] tracking-[0.25em] uppercase text-white/40 mt-2">
          Scroll to explore →
        </p>
      </div>

      {/* Counter */}
      <div className="absolute top-1/2 right-[5vw] -translate-y-1/2 z-20 pointer-events-none">
        <div className="font-mono text-[10px] tracking-[0.3em] uppercase text-white/30 mb-1">
          Works
        </div>
        <div className="font-display text-7xl font-light text-gold/70 tabular-nums">04</div>
      </div>

      <div ref={trackRef} className="flex flex-nowrap h-screen items-center">
        {PORTFOLIO.map((work) => (
          <div
            key={work.id}
            className="portfolio-panel flex-shrink-0 w-screen h-screen flex items-center justify-center"
          >
            <div className="relative w-[min(460px,80vw)] h-[min(580px,70vh)] rounded-3xl overflow-hidden glass cursor-pointer group">
              <Image
                src={work.image}
                alt={work.title}
                fill
                sizes="(max-width: 768px) 80vw, 460px"
                className="portfolio-image object-cover transition-transform duration-1000 group-hover:scale-105"
                quality={85}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent" />
              <div className="portfolio-caption absolute inset-x-0 bottom-0 p-10">
                <div
                  className={cn(
                    'font-mono text-[10px] tracking-[0.3em] uppercase',
                    accentMap[work.accent] ?? 'text-gold'
                  )}
                >
                  {work.category}
                </div>
                <div className="font-display text-3xl font-medium mt-2">{work.title}</div>
                <div className="text-sm text-white/55 mt-2">{work.metric}</div>
                {/* Underline reveal on hover */}
                <div className="mt-5 h-px w-12 bg-gold transition-all duration-500 group-hover:w-32" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
