'use client';

import { useEffect, useRef } from 'react';
import { Video, Instagram, Zap, Sparkles } from 'lucide-react';
import { gsap } from '@/lib/gsap';
import { SERVICES } from '@/lib/constants';
import GlassCard from '@/components/ui/GlassCard';

const iconMap = { video: Video, instagram: Instagram, zap: Zap, sparkles: Sparkles };

const tintMap: Record<string, { bg: string; color: string; glow: string }> = {
  gold: {
    bg: 'bg-gold/[0.08]',
    color: 'text-gold',
    glow: 'group-hover:shadow-[0_0_40px_rgba(200,165,92,0.15)]',
  },
  cyan: {
    bg: 'bg-[#00e5ff]/[0.08]',
    color: 'text-[#00e5ff]',
    glow: 'group-hover:shadow-[0_0_40px_rgba(0,229,255,0.15)]',
  },
  purple: {
    bg: 'bg-[#8b5cf6]/[0.08]',
    color: 'text-[#8b5cf6]',
    glow: 'group-hover:shadow-[0_0_40px_rgba(139,92,246,0.15)]',
  },
  pink: {
    bg: 'bg-[#ec4899]/[0.08]',
    color: 'text-[#ec4899]',
    glow: 'group-hover:shadow-[0_0_40px_rgba(236,72,153,0.15)]',
  },
};

export default function Services() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.service-card', {
        y: 70,
        opacity: 0,
        rotateX: 8,
        stagger: 0.08,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: '.services-grid',
          start: 'top 80%',
          toggleActions: 'play none none reverse',
        },
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      id="services"
      ref={sectionRef}
      className="relative z-10 py-24 md:py-32 px-6 md:px-10"
    >
      <div className="max-w-[1200px] mx-auto">
        <div className="section-label">[ Services ]</div>
        <h2 className="section-title">
          What I<br />
          <span className="italic font-light">Deliver</span>
        </h2>

        <div className="services-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5 mt-10">
          {SERVICES.map((svc) => {
            const Icon = iconMap[svc.icon as keyof typeof iconMap];
            const tint = tintMap[svc.tint];
            return (
              <GlassCard
                key={svc.title}
                tilt
                className={`service-card p-8 cursor-pointer relative overflow-hidden group transition-all duration-500 ${tint.glow}`}
              >
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center ${tint.bg} mb-6 transition-transform group-hover:scale-110`}
                >
                  <Icon className={`w-6 h-6 ${tint.color}`} strokeWidth={1.5} />
                </div>
                <div className="font-display text-xl font-medium mb-3">{svc.title}</div>
                <div className="text-sm text-white/35 leading-relaxed">{svc.desc}</div>
                <div className="mt-6 pt-4 border-t border-white/[0.06] font-mono text-[11px] text-gold flex items-end justify-between">
                  <span>From</span>
                  <span className="text-xl font-bold">${svc.price}</span>
                </div>

                {/* Hover orb */}
                <div
                  className="absolute -bottom-20 -right-20 w-40 h-40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"
                  style={{
                    background:
                      'radial-gradient(circle, rgba(200,165,92,0.15), transparent 70%)',
                    filter: 'blur(20px)',
                  }}
                />
              </GlassCard>
            );
          })}
        </div>
      </div>
    </section>
  );
}
