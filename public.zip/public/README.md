# Public Assets

Drop the following files here to complete the deployment:

- `favicon.ico` — site favicon
- `apple-touch-icon.png` (180×180)
- `og-image.jpg` (1200×630) — used for Open Graph / Twitter cards
- `manifest.json` (optional PWA manifest)

`robots.txt` is already present. The site references these via `app/layout.tsx` metadata.
