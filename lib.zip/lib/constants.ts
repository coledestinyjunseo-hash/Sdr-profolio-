export const SITE = {
  name: 'Shukurat Damilola Rasak',
  shortName: 'SDR',
  role: 'Luxury Digital Brand Strategist',
  tagline: 'Social Media Manager · Growth Specialist · Brand Architect',
  email: 'damilolashukura@gmail.com',
  phone: '+234 903 974 6435',
  phoneHref: 'tel:+2349039746435',
  description:
    'Elite digital strategist specializing in luxury brand positioning, viral content architecture, and audience growth engineering. With an innate understanding of TikTok and Instagram algorithms, she transforms brands from invisible to iconic.',
};

export const NAV_LINKS = [
  { label: 'About', to: 'about' },
  { label: 'Portfolio', to: 'portfolio' },
  { label: 'Analytics', to: 'analytics' },
  { label: 'Services', to: 'services' },
  { label: 'Contact', to: 'contact' },
] as const;

export const SECTIONS = ['hero', 'about', 'portfolio', 'analytics', 'services', 'contact'] as const;
export type SectionId = (typeof SECTIONS)[number];

export const STATS = [
  { value: 50, suffix: '+', label: 'Brands Elevated' },
  { value: 500, suffix: 'K+', label: 'Followers Grown' },
  { value: 200, suffix: '%', label: 'Engagement Lift' },
  { value: 10, suffix: 'M+', label: 'Views Generated' },
] as const;

export const PORTFOLIO = [
  {
    id: 'luxe-noir',
    category: 'Brand Campaign',
    title: 'Luxe Noir Rebrand',
    metric: '340% engagement increase',
    accent: 'gold',
    image:
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=1200&h=1500&fit=crop&q=80',
  },
  {
    id: 'viral-tiktok',
    category: 'TikTok Strategy',
    title: 'Viral Momentum',
    metric: '5M+ organic views in 30 days',
    accent: 'tiktok',
    image:
      'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=1200&h=1500&fit=crop&q=80',
  },
  {
    id: 'instagram-growth',
    category: 'Instagram Growth',
    title: 'Aesthetic Authority',
    metric: '2K → 150K in 6 months',
    accent: 'ig',
    image:
      'https://images.unsplash.com/photo-1611926653458-09294b3142bf?w=1200&h=1500&fit=crop&q=80',
  },
  {
    id: 'prestige-digital',
    category: 'Luxury Campaign',
    title: 'Prestige Digital',
    metric: '12× ROAS achievement',
    accent: 'gold',
    image:
      'https://images.unsplash.com/photo-1523293182086-7651a899d37f?w=1200&h=1500&fit=crop&q=80',
  },
] as const;

export const SERVICES = [
  {
    icon: 'video',
    title: 'TikTok Management',
    desc: 'Full-stack strategy driving organic virality.',
    price: 120,
    tint: 'gold',
  },
  {
    icon: 'instagram',
    title: 'Instagram Growth',
    desc: 'Aesthetic curation and community building.',
    price: 250,
    tint: 'cyan',
  },
  {
    icon: 'zap',
    title: 'Viral Marketing',
    desc: 'Data-driven cultural moment creation.',
    price: 450,
    tint: 'purple',
  },
  {
    icon: 'sparkles',
    title: 'Luxury Campaigns',
    desc: 'Premium high-end brand experiences.',
    price: 700,
    tint: 'pink',
  },
] as const;

export const ANALYTICS = {
  metrics: [
    { label: 'Live Views', value: 2_412_847, change: '+142.3%', live: true },
    { label: 'Profile Visits', value: 89_700, change: '+87.5%', format: 'k' as const },
    { label: 'Followers', value: 347_291, change: '+23.8%' },
    { label: 'Engagement', value: 8.7, change: '+34.1%', format: 'pct' as const },
  ],
  chart: [25, 38, 30, 55, 42, 68, 72, 85, 78, 92, 88, 95],
  territories: [
    { flag: '🇳🇬', name: 'Nigeria', pct: 45.2 },
    { flag: '🇬🇭', name: 'Ghana', pct: 18.7 },
    { flag: '🇬🇧', name: 'United Kingdom', pct: 12.3 },
    { flag: '🇺🇸', name: 'United States', pct: 9.8 },
    { flag: '🇿🇦', name: 'South Africa', pct: 6.1 },
  ],
  topContent: [
    {
      title: 'Morning Routine ✨',
      time: '3 days ago',
      views: '1.2M',
      likes: '89K',
      image:
        'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=224&h=288&fit=crop&q=80',
    },
    {
      title: 'Growth Strategy Vlog',
      time: '1 week ago',
      views: '890K',
      likes: '67K',
      image:
        'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=224&h=288&fit=crop&q=80',
    },
    {
      title: 'Brand Deal Walkthrough',
      time: '2 weeks ago',
      views: '650K',
      likes: '52K',
      image:
        'https://images.unsplash.com/photo-1523293182086-7651a899d37f?w=224&h=288&fit=crop&q=80',
    },
  ],
};

export const AI_INSIGHTS = [
  'Best posting time detected: 7:32 PM GMT+1',
  'Trend spike incoming in your niche',
  'Engagement increased 22% this week',
  'Recommended: Reel format 0:47s performs best',
  'Competitor analysis complete. Gap found.',
  'New hashtag strategy available',
  'Audience shift detected: +12% UK viewers',
];

export const LIVE_NOTIFICATIONS = [
  { color: '#22c55e', text: 'TikTok followers +2.4K today', time: 'Just now' },
  { color: '#c8a55c', text: 'New luxury brand inquiry received', time: '2m ago' },
  { color: '#00e5ff', text: 'Instagram reel hit 500K views', time: '5m ago' },
  { color: '#8b5cf6', text: 'Engagement spike detected: +18%', time: '12m ago' },
  { color: '#fe2c55', text: 'Viral trend alert in your niche', time: '18m ago' },
];
