import type { Metadata, Viewport } from 'next';
import { fraunces, inter, jetbrains } from './fonts';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL('https://shukurat-rasak.vercel.app'),
  title: {
    default: 'Shukurat Damilola Rasak — Luxury Digital Brand Strategist',
    template: '%s · SDR',
  },
  description:
    'Elite digital strategist specializing in luxury brand positioning, viral content architecture, and audience growth engineering on TikTok and Instagram.',
  keywords: [
    'social media manager',
    'TikTok growth',
    'Instagram strategy',
    'luxury brand',
    'digital marketing',
    'viral content',
    'Shukurat Damilola Rasak',
  ],
  authors: [{ name: 'Shukurat Damilola Rasak' }],
  creator: 'Shukurat Damilola Rasak',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    siteName: 'SDR',
    title: 'Shukurat Damilola Rasak — Luxury Digital Brand Strategist',
    description:
      'Transforming brands from invisible to iconic through luxury digital strategy.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Shukurat Damilola Rasak',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Shukurat Damilola Rasak — Luxury Digital Brand Strategist',
    description:
      'Transforming brands from invisible to iconic through luxury digital strategy.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-video-preview': -1,
      'max-snippet': -1,
    },
  },
};

export const viewport: Viewport = {
  themeColor: '#020204',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${fraunces.variable} ${inter.variable} ${jetbrains.variable}`}
    >
      <body className="bg-bg text-white font-sans antialiased">{children}</body>
    </html>
  );
}
