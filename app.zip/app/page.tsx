'use client';

import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';

// Core (above the fold)
import Loader from '@/components/layout/Loader';
import Navigation from '@/components/layout/Navigation';
import Hero from '@/components/sections/Hero';
import { ToastProvider } from '@/components/ui/Toast';

// Heavier components — lazy load (avoids SSR for client-only effects)
const SmoothScrollProvider = dynamic(
  () => import('@/components/effects/SmoothScrollProvider'),
  { ssr: false }
);
const CustomCursor = dynamic(() => import('@/components/effects/CustomCursor'), {
  ssr: false,
});
const ParticleField = dynamic(() => import('@/components/effects/ParticleField'), {
  ssr: false,
});
const AmbientLights = dynamic(() => import('@/components/effects/AmbientLights'), {
  ssr: false,
});
const ScrollProgress = dynamic(() => import('@/components/effects/ScrollProgress'), {
  ssr: false,
});
const SectionIndicator = dynamic(() => import('@/components/layout/SectionIndicator'), {
  ssr: false,
});

const About = dynamic(() => import('@/components/sections/About'));
const Portfolio = dynamic(() => import('@/components/sections/Portfolio'));
const Analytics = dynamic(() => import('@/components/sections/Analytics'));
const Services = dynamic(() => import('@/components/sections/Services'));
const Contact = dynamic(() => import('@/components/sections/Contact'));
const Footer = dynamic(() => import('@/components/layout/Footer'));

const AIAssistant = dynamic(() => import('@/components/widgets/AIAssistant'), {
  ssr: false,
});
const NotificationFeed = dynamic(() => import('@/components/widgets/NotificationFeed'), {
  ssr: false,
});

export default function Home() {
  const [loaded, setLoaded] = useState(false);

  // Lock scroll while loading
  useEffect(() => {
    if (!loaded) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [loaded]);

  return (
    <ToastProvider>
      {!loaded && <Loader onComplete={() => setLoaded(true)} />}

      {/* Effects layer — particles, ambient lights, cursor */}
      <ParticleField />
      <AmbientLights />
      <CustomCursor />
      <ScrollProgress />

      {/* Smooth scroll engine wraps content */}
      <SmoothScrollProvider>
        <Navigation />
        <SectionIndicator />

        <main className="relative z-10">
          <Hero startAnimation={loaded} />

          <div className="section-divider" />
          <About />

          <Portfolio />

          <div className="section-divider" />
          <Analytics />

          <div className="section-divider" />
          <Services />

          <div className="section-divider" />
          <Contact />

          <Footer />
        </main>

        <AIAssistant />
        <NotificationFeed />
      </SmoothScrollProvider>
    </ToastProvider>
  );
}
